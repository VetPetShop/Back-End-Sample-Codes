package com.app.VetPetShop.Pojos;

public enum UserType {
	CUSTOMER, SELLER, DOCTOR, ADMIN
}
