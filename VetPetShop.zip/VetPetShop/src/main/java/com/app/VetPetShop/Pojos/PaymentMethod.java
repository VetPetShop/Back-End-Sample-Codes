package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PaymentMethod")
public class PaymentMethod {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int payMethod_id;	
	
	@ManyToOne
	@JoinColumn
	private Users userId;
	
	@ManyToOne
	@JoinColumn
	private PaymentMethods payMethodId;
	
	@Column(columnDefinition = "TEXT")
	private String paymentDetails;

}
