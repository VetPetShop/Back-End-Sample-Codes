package com.app.VetPetShop.Pojos;

public enum PetCategories {
	DOG, CAT, BIRDS, GOAT, SHEEP, RABBIT, FISH, TURTLES
}