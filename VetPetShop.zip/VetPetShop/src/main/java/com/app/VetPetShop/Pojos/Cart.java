package com.app.VetPetShop.Pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Cart")
public class Cart {
	
	@Id
	private String cartId;
	
	@OneToOne
	@JoinColumn(referencedColumnName = "userId")
	private Users userId;
	
	@Column
	private int totalItems;
	
	@OneToMany(mappedBy = "cartId", cascade = CascadeType.ALL)
	private List<CartItems> cartItems;

}
