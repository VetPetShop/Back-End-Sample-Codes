package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Doctors")
public class Doctors {
	
	@Id
	private String licenseNo;
	
	@OneToOne
	@JoinColumn
	private Users doctorId;
	
	@Column(nullable = false)
	private String specialization;
	
	@Column(nullable = false)
	private String qualification;
	
	@Column(nullable = false)
	private String clinicAddress;

}
