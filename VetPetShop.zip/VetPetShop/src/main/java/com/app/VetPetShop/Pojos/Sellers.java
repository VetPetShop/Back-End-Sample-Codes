package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Sellers")
public class Sellers {
	
	@Id
	private String gstNo;
	
	@OneToOne
	@JoinColumn(referencedColumnName = "userId")
	private Users sellerId;
	
	@Column
	private String sellerPolicy;
	
	@Column
	private int totalSales;

}
