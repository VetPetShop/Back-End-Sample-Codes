package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PetReviews")
public class PetReviews {
	
	@Id
	private String reviewId;
	
	@ManyToOne
	@JoinColumn
	private Pets petId;
	
	@ManyToOne
	@JoinColumn
	private Users userId;
	
	@Column
	private int customerRating;
	
	@Column
	private String review;

}
