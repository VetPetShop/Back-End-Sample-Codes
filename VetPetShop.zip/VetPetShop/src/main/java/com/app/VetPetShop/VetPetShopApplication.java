package com.app.VetPetShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VetPetShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(VetPetShopApplication.class, args);
	}

}
