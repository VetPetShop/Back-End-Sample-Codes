package com.app.VetPetShop.Pojos;

public enum IssueCategories {
	
	ORDER, REFUND, OTHER

}
