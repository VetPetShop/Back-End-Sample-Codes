package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Pets")
public class Pets {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int petId;
	
	@ManyToOne
	@JoinColumn(name = "breedId", nullable = false)
	private PetBreed breedId;
	
	@Column(nullable = false, columnDefinition = "TEXT")
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "sellerId", nullable = false)
	private Users sellerId;
	
	@Column(nullable = false)
	private int petAge;
	
	@Column(nullable = false)
	private char gender;
	
	@Column(nullable = false)
	private double height;
	
	@Column(nullable = false)
	private double weight;
	
	@Column(nullable = false)
	private String petColour;
	
	@Column(columnDefinition = "TEXT")
	private String medicalDetails;
	
	@Column(nullable = false)
	private double price;
	
	@Lob
	private byte[] petImages;

}
