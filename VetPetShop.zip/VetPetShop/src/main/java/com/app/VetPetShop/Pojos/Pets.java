package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Pets")
public class Pets {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int petId;
	
	@ManyToOne
	@JoinColumn
	private PetBreed breedId;
	
	@Column
	private String description;
	
	@ManyToOne
	@JoinColumn
	private Users sellerId;
	
	@Column
	private int petAge;
	
	@Column
	private char gender;
	
	@Column
	private double height;
	
	@Column
	private double weight;
	
	@Column
	private String petColour;
	
	@Column(columnDefinition = "TEXT")
	private String medicalDetails;
	
	@Column
	private double price;
	
	@Lob
	private byte[] petImages;

}
