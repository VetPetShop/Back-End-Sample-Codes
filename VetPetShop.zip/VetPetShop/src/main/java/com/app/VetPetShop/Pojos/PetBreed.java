package com.app.VetPetShop.Pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PetBreed")
public class PetBreed {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int petBreedId;
	
	@Column
	private String breedName;
	
	@Column(columnDefinition = "TEXT")
	private String breedDescription;
	
	@ManyToOne
	@JoinColumn
	private PetCategory petCategoryId;

}
