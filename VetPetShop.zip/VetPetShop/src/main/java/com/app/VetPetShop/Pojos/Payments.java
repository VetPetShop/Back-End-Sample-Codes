package com.app.VetPetShop.Pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Payments")
public class Payments {
	
	@Id
	private String transactionId;
	
	@ManyToOne
	@JoinColumn(name = "userId")
	private Users userId;
	
	@Column
	private double amountPaid;
	
	@Column
	private LocalDate paymentDate;
	
	@ManyToOne
	@JoinColumn(name = "statusId")
	private Status statusId;

}
