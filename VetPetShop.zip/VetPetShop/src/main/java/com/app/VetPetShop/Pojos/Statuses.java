package com.app.VetPetShop.Pojos;

public enum Statuses {
	
	DELIVERED, PENDING, DISPATCHED, CANCELLED, COD, INITIATED, SUCCESS, TRUE, FALSE

}
