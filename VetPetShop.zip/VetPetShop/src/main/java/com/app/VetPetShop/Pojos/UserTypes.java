package com.app.VetPetShop.Pojos;

public enum UserTypes {
	CUSTOMER, SELLER, DOCTOR, ADMIN
}
