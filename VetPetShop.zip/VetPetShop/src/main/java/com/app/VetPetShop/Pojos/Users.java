package com.app.VetPetShop.Pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Users")
public class Users {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	@Column(nullable = false)
	private String firstName;
	
	@Column(nullable = false)
	private String lastName;
	
	@Column(nullable = false)
	private char gender;
	
	@Column
	private LocalDate dob;
	
	@Column(nullable = false, unique = true)
	private String email;
	
	@Column(nullable = false)
	private String password;
	
	@OneToOne
	@JoinColumn(name = "userTypeId", referencedColumnName = "userTypeId")
	private UserType userTypeId;
	
	@Column
	private String address;
	
	@ManyToOne
	@JoinColumn(name = "postId",referencedColumnName = "postOfficeId")
	private PostOffices postId;
	
	@Column(unique = true)
	private String phoneNumber;

}
