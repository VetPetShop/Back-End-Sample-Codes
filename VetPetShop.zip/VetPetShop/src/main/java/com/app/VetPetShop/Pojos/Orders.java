package com.app.VetPetShop.Pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Orders")
public class Orders {
	
	@Id
	private String orderId;
	
	@ManyToOne
	@JoinColumn(name = "transactionId", referencedColumnName = "transactionId")
	private Payments transactionId;
	
	@Column
	private LocalDate orderDate;
	
	@ManyToOne
	@JoinColumn(name = "cartId", referencedColumnName = "cartId")
	private Cart cartId;
	
	@Column
	private int discountGiven;
	
	@Column
	private String shippingAddress;
	
	@Column
	private LocalDate expectedDeliveryDate;
	
	@ManyToOne
	@JoinColumn(name = "statusId", referencedColumnName = "statusId")
	private Status statusId;

}
