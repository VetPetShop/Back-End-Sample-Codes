package com.app.VetPetShop.Pojos;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Refunds")
public class Refunds {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int refundId;
	
	@OneToMany
	@JoinColumn
	private List<Orders> orderId;
	
	@OneToOne
	@JoinColumn(referencedColumnName = "issueId")
	private Issues issueId;
	
	@OneToOne
	@JoinColumn(referencedColumnName = "statusId")
	private Status statusId;

}
