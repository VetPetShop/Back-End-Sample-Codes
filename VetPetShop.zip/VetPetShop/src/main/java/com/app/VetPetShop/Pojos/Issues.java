package com.app.VetPetShop.Pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Issues")
public class Issues {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int issueId;
	
	@ManyToOne
	@JoinColumn(referencedColumnName = "userId")
	private Users userId;
	
	@Enumerated(EnumType.STRING)
	private IssueCategories issueCategory;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn
	private List<Orders> orderId;
	
	@Column(columnDefinition = "TEXT")
	private String description;

}
