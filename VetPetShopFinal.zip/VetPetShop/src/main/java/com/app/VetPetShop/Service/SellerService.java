//package com.app.VetPetShop.Service;
//
//import com.app.VetPetShop.DTO.NewSellerDto;
//import com.app.VetPetShop.Pojos.Sellers;
//import com.app.VetPetShop.Pojos.Users;
//
//public interface SellerService {
//	
//	Sellers getSellerDetails(Users sellerId);
//	
//	String updateTotalSales(Users sellerId, int sales);
//	
//	String registerSeller(NewSellerDto seller);
//	
//	String deleteSeller(Users sellerId);
//
//}
