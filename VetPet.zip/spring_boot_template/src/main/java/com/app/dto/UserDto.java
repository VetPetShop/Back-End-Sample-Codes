package com.app.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.app.pojo.PostOffice;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
 @ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
	//@NotBlank(message = "First Name can't be blank")

	private String firstName;

	//@NotBlank(message = "Last Name can't be blank")
	private String lastName;

	private char gender;

	private LocalDate dob;

	
	//@NotBlank(message = "Email can't be blank")

	private String email;

//	@NotBlank(message = "Password can't be blank")
	
	private String password;

	private String address;

	private String phoneNumber;

}
