package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.dto.UserDto;
import com.app.dto.UserLoginDto;
import com.app.service.UserService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/add-new-user")
	public ApiResponse addNewUser(@RequestBody @Valid UserDto userDto) {
		System.out.println(userDto.getEmail());
		
		userService.addUser(userDto);
		return new ApiResponse("User added successfully");
	}

	@GetMapping("/login")
	public ApiResponse AuthenticateUser(UserLoginDto userLoginDto) {
		userService.authenticateUser(userLoginDto);
		return new ApiResponse("Login successful");
	}

	@PostMapping("/update-user-details")
	public ApiResponse updateUserDetails(UserDto userDto) {
		userService.updateUserDetails(userDto);
		return new ApiResponse("Details updated successfully");
	}
}
