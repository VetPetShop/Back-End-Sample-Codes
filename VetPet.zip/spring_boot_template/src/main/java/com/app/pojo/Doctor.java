package com.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Doctors")
public class Doctor {
	
	@Id
	private String licenseNo;
	
	@OneToOne
	@JoinColumn(name = "doctorId", referencedColumnName = "userId")
	private User doctorId;
	
	@Column(nullable = false)
	private String specialization;
	
	@Column(nullable = false)
	private String qualification;
	
	@Column(nullable = false)
	private String clinicAddress;

	

	public Doctor(String licenseNo, String specialization, String qualification, String clinicAddress) {
		super();
		this.licenseNo = licenseNo;
		this.specialization = specialization;
		this.qualification = qualification;
		this.clinicAddress = clinicAddress;
	}

	
	
}
