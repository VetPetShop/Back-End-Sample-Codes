package com.app.pojo;

public enum PetCategoryEnum {
	DOG, CAT, BIRDS, OTHERS
}