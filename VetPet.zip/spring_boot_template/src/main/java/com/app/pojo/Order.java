package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Orders")
public class Order {
	
	@Id
	private int orderId;
	
	@ManyToOne
	@JoinColumn(name = "transactionId", referencedColumnName = "transactionId")
	private Payment transactionId;
	
	@Column
	private LocalDate orderDate;
	
	@ManyToOne
	@JoinColumn(name = "cartId", referencedColumnName = "cartId")
	private Cart cartId;
	
	
	@Column
	private String shippingAddress;
	
	@Column
	private LocalDate expectedDeliveryDate;
	
	@ManyToOne
	@JoinColumn(name = "statusId", referencedColumnName = "statusId")
	private Status statusId;

	public Order(LocalDate orderDate, String shippingAddress, LocalDate expectedDeliveryDate) {
		super();
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	
}
