package com.app.pojo;

public enum StatusEnum {
	
	DELIVERED, PENDING, DISPATCHED, CANCELLED ,TRUE, FALSE

}
