package com.app.pojo;

public enum UserTypeEnum {
	ADMIN, USER,SELLER, DOCTOR
}
