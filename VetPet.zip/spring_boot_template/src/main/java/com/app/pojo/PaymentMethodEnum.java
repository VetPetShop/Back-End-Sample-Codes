package com.app.pojo;

public enum PaymentMethodEnum {
	UPI, COD, CREDIT, DEBIT;

}
