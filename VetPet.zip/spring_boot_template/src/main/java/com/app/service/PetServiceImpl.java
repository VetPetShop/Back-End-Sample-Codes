package com.app.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

@Service
@Transactional
public class PetServiceImpl implements PetService {

}
