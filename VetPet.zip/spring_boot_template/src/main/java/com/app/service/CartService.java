package com.app.service;


import com.app.pojo.Cart;


public interface CartService {

    Cart getCartById(int cartId);

    Cart updateCart(int cartId, Cart newCartData);

    boolean deleteCart(int cartId);

	
}

