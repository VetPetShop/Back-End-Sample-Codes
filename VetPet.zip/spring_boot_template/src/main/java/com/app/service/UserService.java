package com.app.service;

import com.app.dto.UserDto;
import com.app.dto.UserLoginDto;
import com.app.pojo.User;

public interface UserService {

	String addUser(UserDto userDto);
	UserDto authenticateUser(UserLoginDto userLoginDto);
	boolean existsByEmail(String email);
	String updateUserDetails(UserDto userDto);
}
