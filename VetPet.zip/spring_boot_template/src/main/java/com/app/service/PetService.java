package com.app.service;

public interface PetService {

}
