package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_excceptions.ResourceNotFoundException;
import com.app.pojo.Cart;
import com.app.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;

    @Autowired
    public CartServiceImpl(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }
    
    @Override
    public Cart getCartById(int cartId) {
        Optional<Cart> optionalCart = cartRepository.findById(cartId);
        return optionalCart.orElseThrow(() -> new ResourceNotFoundException("Cart with ID " + cartId + " not found"));
    }


	/*
	 * @Override public Cart getCartById(int cartId) { Optional<Cart> optionalCart =
	 * cartRepository.findById(cartId); return optionalCart.orElse(null); }
	 */

   

	/*
	 
	 * cartToUpdate.setTotalItems(newCartData.getTotalItems()); // Update the fields
	 * of the cartToUpdate object with the newCartData // For example:
	 * cartToUpdate.setTotalItems(newCartData.getTotalItems()); // Update any other
	 * relevant fields return cartRepository.save(cartToUpdate); } else { return
	 * null; } }
	 */
    @Override
    public Cart updateCart(int cartId, Cart newCartData) {
        Optional<Cart> optionalCart = cartRepository.findById(cartId);
        if (optionalCart.isPresent()) {
            Cart cartToUpdate = optionalCart.get();
            
            // Update the fields of the cartToUpdate object with the newCartData
            cartToUpdate.setTotalItems(newCartData.getTotalItems());
            // Update any other relevant fields
            
            return cartRepository.save(cartToUpdate);
        } else {
            throw new ResourceNotFoundException("Cart with ID " + cartId + " not found");
        }
    }

    
    
    @Override
    public boolean deleteCart(int cartId) {
        Optional<Cart> optionalCart = cartRepository.findById(cartId);
        if (optionalCart.isPresent()) {
            cartRepository.deleteById(cartId);
            return true;
        } else {
        	throw new ResourceNotFoundException("Cart with ID " + cartId + " not found");
        }
    }
}
